﻿namespace WindowsFormsApp2
{
    partial class SanrioMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(SanrioMain));
            this.lblQuest1 = new System.Windows.Forms.Label();
            this.btnAns1 = new System.Windows.Forms.Button();
            this.btnAns2 = new System.Windows.Forms.Button();
            this.btnAns3 = new System.Windows.Forms.Button();
            this.lblYr = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.NumBox = new System.Windows.Forms.RichTextBox();
            this.btnYr = new System.Windows.Forms.Button();
            this.lblQuest3 = new System.Windows.Forms.Label();
            this.chckBox1 = new System.Windows.Forms.CheckBox();
            this.chckBox2 = new System.Windows.Forms.CheckBox();
            this.chckBox3 = new System.Windows.Forms.CheckBox();
            this.lblQuest4 = new System.Windows.Forms.Label();
            this.NumUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.lblApples = new System.Windows.Forms.Label();
            this.NumUpDown = new System.Windows.Forms.Button();
            this.btnName = new System.Windows.Forms.Button();
            this.lblQuest5 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.ComboBox();
            this.lblHk_Bf = new System.Windows.Forms.LinkLabel();
            this.btnScore = new System.Windows.Forms.Button();
            this.lblQuest2 = new System.Windows.Forms.Label();
            this.btnSanrioMart = new System.Windows.Forms.Button();
            this.lblMessage1 = new System.Windows.Forms.Label();
            this.lblMessage2 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gamesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groceryToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.mazeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.extrasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.youTubeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.storeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblQuest1
            // 
            this.lblQuest1.AutoSize = true;
            this.lblQuest1.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest1.Location = new System.Drawing.Point(247, 45);
            this.lblQuest1.Name = "lblQuest1";
            this.lblQuest1.Size = new System.Drawing.Size(420, 24);
            this.lblQuest1.TabIndex = 0;
            this.lblQuest1.Text = "1. Who is the most recognizable Sanrio character? ";
            // 
            // btnAns1
            // 
            this.btnAns1.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnAns1.Location = new System.Drawing.Point(117, 90);
            this.btnAns1.Name = "btnAns1";
            this.btnAns1.Size = new System.Drawing.Size(162, 46);
            this.btnAns1.TabIndex = 1;
            this.btnAns1.Text = "Hello Kitty ";
            this.btnAns1.UseVisualStyleBackColor = false;
            this.btnAns1.Click += new System.EventHandler(this.PushMe_Click);
            // 
            // btnAns2
            // 
            this.btnAns2.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnAns2.Location = new System.Drawing.Point(353, 90);
            this.btnAns2.Name = "btnAns2";
            this.btnAns2.Size = new System.Drawing.Size(181, 46);
            this.btnAns2.TabIndex = 2;
            this.btnAns2.Text = "Pompompurin";
            this.btnAns2.UseVisualStyleBackColor = false;
            this.btnAns2.Click += new System.EventHandler(this.PushMe_Clck2);
            // 
            // btnAns3
            // 
            this.btnAns3.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnAns3.Location = new System.Drawing.Point(627, 90);
            this.btnAns3.Name = "btnAns3";
            this.btnAns3.Size = new System.Drawing.Size(172, 46);
            this.btnAns3.TabIndex = 3;
            this.btnAns3.Text = "Cinnamonroll";
            this.btnAns3.UseVisualStyleBackColor = false;
            this.btnAns3.Click += new System.EventHandler(this.PushMe_Clck3);
            // 
            // lblYr
            // 
            this.lblYr.AutoSize = true;
            this.lblYr.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYr.Location = new System.Drawing.Point(247, 235);
            this.lblYr.Name = "lblYr";
            this.lblYr.Size = new System.Drawing.Size(48, 24);
            this.lblYr.TabIndex = 5;
            this.lblYr.Text = "Year";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.label1.Location = new System.Drawing.Point(350, 265);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 18);
            this.label1.TabIndex = 6;
            // 
            // NumBox
            // 
            this.NumBox.Location = new System.Drawing.Point(320, 235);
            this.NumBox.Name = "NumBox";
            this.NumBox.Size = new System.Drawing.Size(69, 30);
            this.NumBox.TabIndex = 7;
            this.NumBox.Text = "";
            // 
            // btnYr
            // 
            this.btnYr.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnYr.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnYr.Location = new System.Drawing.Point(442, 235);
            this.btnYr.Name = "btnYr";
            this.btnYr.Size = new System.Drawing.Size(171, 36);
            this.btnYr.TabIndex = 8;
            this.btnYr.Text = "Check Year";
            this.btnYr.UseVisualStyleBackColor = false;
            this.btnYr.Click += new System.EventHandler(this.CheckInt_Click);
            // 
            // lblQuest3
            // 
            this.lblQuest3.AutoSize = true;
            this.lblQuest3.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest3.Location = new System.Drawing.Point(103, 299);
            this.lblQuest3.Name = "lblQuest3";
            this.lblQuest3.Size = new System.Drawing.Size(221, 24);
            this.lblQuest3.TabIndex = 9;
            this.lblQuest3.Text = "3. How tall is Hello Kitty? ";
            // 
            // chckBox1
            // 
            this.chckBox1.AutoSize = true;
            this.chckBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckBox1.Location = new System.Drawing.Point(315, 302);
            this.chckBox1.Name = "chckBox1";
            this.chckBox1.Size = new System.Drawing.Size(100, 22);
            this.chckBox1.TabIndex = 10;
            this.chckBox1.Text = "4 Bananas";
            this.chckBox1.UseVisualStyleBackColor = true;
            this.chckBox1.CheckedChanged += new System.EventHandler(this.Check1);
            // 
            // chckBox2
            // 
            this.chckBox2.AutoSize = true;
            this.chckBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckBox2.Location = new System.Drawing.Point(435, 302);
            this.chckBox2.Name = "chckBox2";
            this.chckBox2.Size = new System.Drawing.Size(90, 22);
            this.chckBox2.TabIndex = 11;
            this.chckBox2.Text = "5 Apples ";
            this.chckBox2.UseVisualStyleBackColor = true;
            this.chckBox2.CheckedChanged += new System.EventHandler(this.Check2);
            // 
            // chckBox3
            // 
            this.chckBox3.AutoSize = true;
            this.chckBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chckBox3.Location = new System.Drawing.Point(549, 302);
            this.chckBox3.Name = "chckBox3";
            this.chckBox3.Size = new System.Drawing.Size(99, 22);
            this.chckBox3.TabIndex = 12;
            this.chckBox3.Text = "7 Oranges";
            this.chckBox3.UseVisualStyleBackColor = true;
            this.chckBox3.CheckedChanged += new System.EventHandler(this.Check3);
            // 
            // lblQuest4
            // 
            this.lblQuest4.AutoSize = true;
            this.lblQuest4.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest4.Location = new System.Drawing.Point(119, 379);
            this.lblQuest4.Name = "lblQuest4";
            this.lblQuest4.Size = new System.Drawing.Size(305, 24);
            this.lblQuest4.TabIndex = 13;
            this.lblQuest4.Text = "4. How much does Hello Kitty weigh?";
            // 
            // NumUpDown1
            // 
            this.NumUpDown1.Location = new System.Drawing.Point(412, 379);
            this.NumUpDown1.Maximum = new decimal(new int[] {
            6,
            0,
            0,
            0});
            this.NumUpDown1.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.NumUpDown1.Name = "NumUpDown1";
            this.NumUpDown1.Size = new System.Drawing.Size(33, 24);
            this.NumUpDown1.TabIndex = 0;
            this.NumUpDown1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.NumUpDown1.Value = new decimal(new int[] {
            3,
            0,
            0,
            0});
            // 
            // lblApples
            // 
            this.lblApples.AutoSize = true;
            this.lblApples.Location = new System.Drawing.Point(451, 381);
            this.lblApples.Name = "lblApples";
            this.lblApples.Size = new System.Drawing.Size(56, 18);
            this.lblApples.TabIndex = 15;
            this.lblApples.Text = "Apples ";
            // 
            // NumUpDown
            // 
            this.NumUpDown.BackColor = System.Drawing.Color.LavenderBlush;
            this.NumUpDown.Location = new System.Drawing.Point(518, 374);
            this.NumUpDown.Name = "NumUpDown";
            this.NumUpDown.Size = new System.Drawing.Size(134, 36);
            this.NumUpDown.TabIndex = 16;
            this.NumUpDown.Text = "Check Weight";
            this.NumUpDown.UseVisualStyleBackColor = false;
            this.NumUpDown.Click += new System.EventHandler(this.CheckInt_Click2);
            // 
            // btnName
            // 
            this.btnName.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnName.Location = new System.Drawing.Point(552, 440);
            this.btnName.Name = "btnName";
            this.btnName.Size = new System.Drawing.Size(127, 39);
            this.btnName.TabIndex = 17;
            this.btnName.Text = "Check Name";
            this.btnName.UseVisualStyleBackColor = false;
            this.btnName.Click += new System.EventHandler(this.CheckInt_Click3);
            // 
            // lblQuest5
            // 
            this.lblQuest5.AutoSize = true;
            this.lblQuest5.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest5.Location = new System.Drawing.Point(41, 446);
            this.lblQuest5.Name = "lblQuest5";
            this.lblQuest5.Size = new System.Drawing.Size(392, 24);
            this.lblQuest5.TabIndex = 18;
            this.lblQuest5.Text = "5. What is the name of Hello Kitty\'s boyfriend?";
            // 
            // nameBox
            // 
            this.nameBox.AllowDrop = true;
            this.nameBox.FormattingEnabled = true;
            this.nameBox.Items.AddRange(new object[] {
            "Monkichi",
            "Tuxedo Penguin",
            "Dear Daniel ",
            "Charmy Kitty ",
            "Badtz Maru"});
            this.nameBox.Location = new System.Drawing.Point(418, 447);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(116, 26);
            this.nameBox.TabIndex = 19;
            // 
            // lblHk_Bf
            // 
            this.lblHk_Bf.AutoSize = true;
            this.lblHk_Bf.DisabledLinkColor = System.Drawing.Color.Red;
            this.lblHk_Bf.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHk_Bf.LinkColor = System.Drawing.Color.Indigo;
            this.lblHk_Bf.Location = new System.Drawing.Point(113, 503);
            this.lblHk_Bf.Name = "lblHk_Bf";
            this.lblHk_Bf.Size = new System.Drawing.Size(577, 24);
            this.lblHk_Bf.TabIndex = 20;
            this.lblHk_Bf.TabStop = true;
            this.lblHk_Bf.Text = "Click here to see Hello Kitty and her boyfriend spending time together";
            this.lblHk_Bf.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lblHk_Bf_LinkClicked);
            // 
            // btnScore
            // 
            this.btnScore.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnScore.Location = new System.Drawing.Point(726, 265);
            this.btnScore.Name = "btnScore";
            this.btnScore.Size = new System.Drawing.Size(142, 95);
            this.btnScore.TabIndex = 21;
            this.btnScore.Text = "Click to View Score";
            this.btnScore.UseVisualStyleBackColor = false;
            this.btnScore.Click += new System.EventHandler(this.btnCheckScore_Click);
            // 
            // lblQuest2
            // 
            this.lblQuest2.AutoSize = true;
            this.lblQuest2.Font = new System.Drawing.Font("Comic Sans MS", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuest2.Location = new System.Drawing.Point(139, 180);
            this.lblQuest2.Name = "lblQuest2";
            this.lblQuest2.Size = new System.Drawing.Size(657, 24);
            this.lblQuest2.TabIndex = 22;
            this.lblQuest2.Text = "2. What year was Hello Kitty created if she is celebrating her 51st year in 2026?" +
    "";
            // 
            // btnSanrioMart
            // 
            this.btnSanrioMart.BackColor = System.Drawing.Color.LavenderBlush;
            this.btnSanrioMart.Font = new System.Drawing.Font("Microsoft JhengHei UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSanrioMart.Location = new System.Drawing.Point(726, 447);
            this.btnSanrioMart.Name = "btnSanrioMart";
            this.btnSanrioMart.Size = new System.Drawing.Size(202, 70);
            this.btnSanrioMart.TabIndex = 23;
            this.btnSanrioMart.Text = "Go Grocery Shopping with Hello Kitty";
            this.btnSanrioMart.UseVisualStyleBackColor = false;
            this.btnSanrioMart.Click += new System.EventHandler(this.btnSanrioMart_Click);
            // 
            // lblMessage1
            // 
            this.lblMessage1.AutoSize = true;
            this.lblMessage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage1.ForeColor = System.Drawing.Color.ForestGreen;
            this.lblMessage1.Location = new System.Drawing.Point(623, 45);
            this.lblMessage1.Name = "lblMessage1";
            this.lblMessage1.Size = new System.Drawing.Size(0, 31);
            this.lblMessage1.TabIndex = 24;
            this.lblMessage1.Visible = false;
            // 
            // lblMessage2
            // 
            this.lblMessage2.AutoSize = true;
            this.lblMessage2.BackColor = System.Drawing.Color.Transparent;
            this.lblMessage2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMessage2.ForeColor = System.Drawing.Color.Crimson;
            this.lblMessage2.Location = new System.Drawing.Point(633, 222);
            this.lblMessage2.Name = "lblMessage2";
            this.lblMessage2.Size = new System.Drawing.Size(69, 25);
            this.lblMessage2.TabIndex = 25;
            this.lblMessage2.Text = "label 2";
            this.lblMessage2.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.gamesToolStripMenuItem,
            this.extrasToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(948, 26);
            this.menuStrip1.TabIndex = 27;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ReturnToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(49, 22);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // ReturnToolStripMenuItem
            // 
            this.ReturnToolStripMenuItem.Name = "ReturnToolStripMenuItem";
            this.ReturnToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.ReturnToolStripMenuItem.Text = "Return to Sanrio Menu";
            this.ReturnToolStripMenuItem.Click += new System.EventHandler(this.ReturnToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(260, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click_1);
            // 
            // gamesToolStripMenuItem
            // 
            this.gamesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.groceryToolStripMenuItem2,
            this.mazeToolStripMenuItem});
            this.gamesToolStripMenuItem.Name = "gamesToolStripMenuItem";
            this.gamesToolStripMenuItem.Size = new System.Drawing.Size(76, 22);
            this.gamesToolStripMenuItem.Text = "Games";
            // 
            // groceryToolStripMenuItem2
            // 
            this.groceryToolStripMenuItem2.Name = "groceryToolStripMenuItem2";
            this.groceryToolStripMenuItem2.Size = new System.Drawing.Size(231, 26);
            this.groceryToolStripMenuItem2.Text = "Grocery Shopping ";
            this.groceryToolStripMenuItem2.Click += new System.EventHandler(this.groceryToolStripMenuItem2_Click);
            // 
            // mazeToolStripMenuItem
            // 
            this.mazeToolStripMenuItem.Name = "mazeToolStripMenuItem";
            this.mazeToolStripMenuItem.Size = new System.Drawing.Size(231, 26);
            this.mazeToolStripMenuItem.Text = "Maze Game";
            this.mazeToolStripMenuItem.Click += new System.EventHandler(this.mazeToolStripMenuItem_Click_1);
            // 
            // extrasToolStripMenuItem
            // 
            this.extrasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.youTubeToolStripMenuItem,
            this.storeToolStripMenuItem});
            this.extrasToolStripMenuItem.Name = "extrasToolStripMenuItem";
            this.extrasToolStripMenuItem.Size = new System.Drawing.Size(70, 22);
            this.extrasToolStripMenuItem.Text = "Extras";
            // 
            // youTubeToolStripMenuItem
            // 
            this.youTubeToolStripMenuItem.Name = "youTubeToolStripMenuItem";
            this.youTubeToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.youTubeToolStripMenuItem.Text = "Hello Kitty YouTube Link";
            this.youTubeToolStripMenuItem.Click += new System.EventHandler(this.youTubeToolStripMenuItem_Click);
            // 
            // storeToolStripMenuItem
            // 
            this.storeToolStripMenuItem.Name = "storeToolStripMenuItem";
            this.storeToolStripMenuItem.Size = new System.Drawing.Size(274, 26);
            this.storeToolStripMenuItem.Text = "Sanrio Store";
            this.storeToolStripMenuItem.Click += new System.EventHandler(this.storeToolStripMenuItem_Click);
            // 
            // SanrioMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.LightPink;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(948, 679);
            this.Controls.Add(this.lblMessage2);
            this.Controls.Add(this.lblMessage1);
            this.Controls.Add(this.btnSanrioMart);
            this.Controls.Add(this.lblQuest2);
            this.Controls.Add(this.btnScore);
            this.Controls.Add(this.lblHk_Bf);
            this.Controls.Add(this.nameBox);
            this.Controls.Add(this.lblQuest5);
            this.Controls.Add(this.btnName);
            this.Controls.Add(this.NumUpDown);
            this.Controls.Add(this.lblApples);
            this.Controls.Add(this.NumUpDown1);
            this.Controls.Add(this.lblQuest4);
            this.Controls.Add(this.chckBox3);
            this.Controls.Add(this.chckBox2);
            this.Controls.Add(this.chckBox1);
            this.Controls.Add(this.lblQuest3);
            this.Controls.Add(this.btnYr);
            this.Controls.Add(this.NumBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblYr);
            this.Controls.Add(this.btnAns3);
            this.Controls.Add(this.btnAns2);
            this.Controls.Add(this.btnAns1);
            this.Controls.Add(this.lblQuest1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "SanrioMain";
            this.Text = " Sanrio GUI";
            this.Load += new System.EventHandler(this.SanrioMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.NumUpDown1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblQuest1;
        private System.Windows.Forms.Button btnAns1;
        private System.Windows.Forms.Button PushMe_Click2;
        private System.Windows.Forms.Button btnAns3;
        private System.Windows.Forms.Button btnAns2;
        private System.Windows.Forms.Label lblYr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox NumBox;
        private System.Windows.Forms.Button btnYr;
        private System.Windows.Forms.Label lblQuest3;
        private System.Windows.Forms.CheckBox chckBox1;
        private System.Windows.Forms.CheckBox chckBox2;
        private System.Windows.Forms.CheckBox chckBox3;
        private System.Windows.Forms.Label lblQuest4;
        private System.Windows.Forms.NumericUpDown NumUpDown1;
        private System.Windows.Forms.Label lblApples;
        private System.Windows.Forms.Button NumUpDown;
        private System.Windows.Forms.Button btnName;
        private System.Windows.Forms.Label lblQuest5;
        private System.Windows.Forms.ComboBox nameBox;
        private System.Windows.Forms.LinkLabel lblHk_Bf;
        private System.Windows.Forms.Button btnScore;
        private System.Windows.Forms.Label lblQuest2;
        private System.Windows.Forms.Button btnSanrioMart;
        private System.Windows.Forms.Label lblMessage1;
        private System.Windows.Forms.Label lblMessage2;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem gamesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem groceryToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem mazeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem extrasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem youTubeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem storeToolStripMenuItem;
    }
}